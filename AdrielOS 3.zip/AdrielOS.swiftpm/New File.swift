import SwiftUI

struct SetupView: View {
    @State var setupStep = 0
    @State var isShowingInfo = false
    
    var body: some View {
        ZStack {
            // Background Layer
            Image("Bkg")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            RoundedRectangle(cornerRadius: 20)
                .glassEffect(.clear, in: .rect(cornerRadius: 20)) 
                .frame(width: 350, height: 500)
            
            VStack {
                    VStack(spacing: 20) {
                        Text("computer setup")
                            .font(.system(size: 35))
                            .fontDesign(.rounded)
                            .bold()
                        
                        Text("welcome to computer setup, \nplease continue to setup.")
                            .multilineTextAlignment(.center)
                        
                        Image(systemName: "desktopcomputer.and.arrow.down")
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(.blue.opacity(0.57), .blue)
                            .symbolEffect(.pulse)
                            .font(.system(size: 75))
                        
                        Button(action: {setupStep += 1}) {
                            HStack {
                                Text("setup os")
                                Image(systemName: "arrow.right.square")
                            }
                            .foregroundColor(.white)
                            .padding(7)
                            .clipShape(.rect(cornerRadius: 7))
                            .glassEffect(.regular.tint(.green), in: .rect(cornerRadius: 7))
                        }
                        }
                    .foregroundColor(.black)
                }
        }
    }
}

#Preview {
    SetupView()
}

